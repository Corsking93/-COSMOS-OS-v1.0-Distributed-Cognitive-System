
import { useEffect, useState } from "react";

export default function App() {
  const [log, setLog] = useState([]);

  useEffect(() => {
    const ws = new WebSocket("ws://localhost:9000");

    ws.onmessage = (e) => {
      setLog((l) => [...l, e.data]);
    };
  }, []);

  return (
    <div style={{background:"black",color:"lime",height:"100vh"}}>
      <h1>COSMOS RL DASHBOARD</h1>
      <pre>{log.map((l,i)=><div key={i}>{l}</div>)}</pre>
    </div>
  );
}
