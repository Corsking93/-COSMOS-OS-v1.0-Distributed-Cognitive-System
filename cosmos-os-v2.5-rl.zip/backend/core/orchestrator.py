
class Orchestrator:
    def __init__(self, nodes):
        self.nodes = nodes

    def broadcast(self, signal):
        return [n.process(signal) for n in self.nodes]
