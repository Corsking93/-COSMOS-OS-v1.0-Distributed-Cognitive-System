
class Memory:
    def __init__(self):
        self.data = []

    def store(self, item):
        self.data.append(item)

    def recall(self):
        return self.data[-5:]
