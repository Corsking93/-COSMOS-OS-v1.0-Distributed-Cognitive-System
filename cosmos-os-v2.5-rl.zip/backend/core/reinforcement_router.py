
import random
import json
import os

class ReinforcementRouter:
    def __init__(self):
        self.weights = {"openai": 0.5, "local": 0.5}
        self.epsilon = 0.2
        self.memory_file = "router_weights.json"
        self.load()

    def choose(self, signal):
        if random.random() < self.epsilon:
            return random.choice(["openai", "local"])

        return max(self.weights, key=self.weights.get)

    def update(self, model, reward):
        self.weights[model] += 0.1 * reward
        self.normalize()
        self.save()

    def normalize(self):
        total = sum(self.weights.values())
        for k in self.weights:
            self.weights[k] /= total

    def save(self):
        with open(self.memory_file, "w") as f:
            json.dump(self.weights, f)

    def load(self):
        if os.path.exists(self.memory_file):
            self.weights = json.load(open(self.memory_file))
