
from core.reinforcement_router import ReinforcementRouter
from core.local_brain import LocalBrain
from core.openai_brain import OpenAIBrain

class CosmosNode:
    def __init__(self, node_id):
        self.id = node_id
        self.router = ReinforcementRouter()
        self.local = LocalBrain()
        self.openai = OpenAIBrain()

    def process(self, signal):

        model = self.router.choose(signal)

        if model == "openai":
            result = self.openai.think([], signal)
        else:
            result = self.local.think([], signal)

        # simulated reward (quality heuristic)
        reward = result["confidence"]

        self.router.update(model, reward)

        return {
            "node": self.id,
            "used_model": model,
            "result": result,
            "reward": reward,
            "weights": self.router.weights
        }
