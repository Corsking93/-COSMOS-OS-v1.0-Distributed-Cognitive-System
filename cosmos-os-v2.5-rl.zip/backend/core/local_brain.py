
class LocalBrain:
    def think(self, context, signal):
        return {
            "model": "local",
            "response": f"[LOCAL] processed: {signal}",
            "confidence": 0.6
        }
