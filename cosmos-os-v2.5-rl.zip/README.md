
COSMOS OS v2.5 RL

Features:
- Reinforcement router (learns OpenAI vs Local usage)
- Multi-node swarm
- Hybrid brain system

Run:
bash install.sh
