
#!/bin/bash
echo 'Starting COSMOS v2.5 RL...'
docker compose -f swarm/docker-compose.yml up --build
