
COSMOS OS v2 (Swarm Prototype)

Run:
bash install.sh
