
export default function App(){
  return <div style={{color:'lime',background:'black',height:'100vh'}}>
  COSMOS DASHBOARD
  </div>
}
