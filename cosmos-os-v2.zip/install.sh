
#!/bin/bash
docker compose -f swarm/docker-compose.yml up --build
