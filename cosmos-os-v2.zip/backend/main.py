
from core.node import CosmosNode
from core.orchestrator import Orchestrator

nodes = [CosmosNode("A"), CosmosNode("B"), CosmosNode("C")]
orch = Orchestrator(nodes)

print("COSMOS OS v2 RUNNING")

while True:
    s = input("cosmos> ")
    if s == "exit":
        break
    print(orch.broadcast(s))
