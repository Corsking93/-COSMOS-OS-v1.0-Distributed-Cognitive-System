
class Orchestrator:
    def __init__(self, nodes):
        self.nodes = nodes

    def broadcast(self, signal):
        results = [n.process(signal) for n in self.nodes]
        return {"results": results}
