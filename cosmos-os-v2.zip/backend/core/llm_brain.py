
class LLMBrain:
    def think(self, context, signal):
        return {
            "decision": "ANALYZE",
            "confidence": 0.8
        }
